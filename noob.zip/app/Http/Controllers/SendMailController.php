<?php

namespace App\Http\Controllers;

class SendMailController extends Controller
{
    public function forgetPassword() {
        return view('');
    }
}
