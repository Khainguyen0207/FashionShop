<?php include "includes/header.php" ?>

<head>
    <link rel="stylesheet" href="../assets/Dashboard/css/cskh.css">
</head>
<body>
    <section>
        <div id="header">
        </div>
    </section>
    <section>
        <div id="container">
            <div class="menu-bar">
                <?php include "includes/menubar.php" ?>
            </div>

            <div class="overview">

            </div>
        </div>
    </section>
    <div id="footer">

    </div>
</body>
</html>