<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            
        }

        body {
            width: 100%;
            height: 100vh;
            background-color: bisque;
        }

        .notifition {
            position: absolute;
            text-align: center;
            bottom: 0;
            left: 0;
            right: 0;
            color: black;
            font-family: Verdana, Geneva, Tahoma, sans-serif, Courier, monospace;
        }
        
        .img-404 {
            position: absolute;
            height: 100vh;
            width: 100%;    
            background-image: url(https://cdn.pixabay.com/photo/2021/07/21/12/49/error-6482984_960_720.png);
            background-size: contain;
            align-items : center;
            justify-content: center;
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body>
    <div class="img-404">
        <h1 class="notifition">Anh yêu em thì có chứ trang thì không tìm thấy</h1>
    </div>
</body>
</html>