<!DOCTYPE html>
<html>
<head>
    <title>Laravel SweetAlert Example</title>
    <link rel="stylesheet" href="{{asset('assets/css/auth.css')}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
    </head>
<body>
    <div class="alert alert-danger my-animation">
        <span>Tài khoản hoặc mật khẩu không đúng</span>
    </div>
</body>
</html>