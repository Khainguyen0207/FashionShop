
<?php $__env->startPush('head'); ?>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>" type="image/x-icon">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <label for="">Người dùng: <?php echo e($name); ?></label>
        <?php if($role == 1): ?>
            <p>Phân quyền: Admin</p>
            <a href="<?php echo e(route('admin.home')); ?>">Chuyển trang admin</a>
        <?php else: ?>
            <p>Phân quyền: Người dùng</p>
        <?php endif; ?>
    </div>
    <form action="<?php echo e(route('user.logout')); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit">Đăng xuất</button>
    </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\noob\resources\views/user/home.blade.php ENDPATH**/ ?>