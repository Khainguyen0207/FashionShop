
<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/customer.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('overview'); ?>
<div class="overview">
    <div id="header">
        <h1>Danh sách khách hàng</h1>
    </div>
    <div class="toolbar">
        <div class="menu">
            <p><i class="fa-solid fa-bars fa-xl"></i></p>
        </div>
        <div class="search">
            <input id="text" type="text" placeholder="Mã khách hàng"> 
            <input id="text" type="text" placeholder="Tên khách hàng"> 
            <input id="text" type="email" placeholder="Email"> 
            <a href="#" onclick="alert(document.getElementById('text').value)">Tìm kiếm</a>
        </div>
    </div> 
    <?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="footer">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\noob\resources\views/admin/customer.blade.php ENDPATH**/ ?>