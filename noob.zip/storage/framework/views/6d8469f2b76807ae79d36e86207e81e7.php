<?php if(count($errors) > 0): ?>
    <!-- Form Error List -->
    <div class="alert alert-danger my-animation-alert">
        <span id="errors">
            <?php echo e($errors->first()); ?>

        </span>
    </div>
<?php endif; ?>

<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-success my-animation-alert">
        <span id="success">
            <?php echo e(session('success')); ?>

        </span>
    </div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?><?php /**PATH C:\laragon\www\noob\resources\views/common/error.blade.php ENDPATH**/ ?>