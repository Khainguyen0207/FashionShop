<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo e($tittle); ?></title>
        <?php echo $__env->yieldPushContent('head'); ?>
    </head>
    <body>
        <?php echo $__env->make('common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html><?php /**PATH C:\laragon\www\noob\resources\views/layouts/user.blade.php ENDPATH**/ ?>