

<?php $__env->startSection('content'); ?>
<div id="main">
    <div class="form">
        <form action="<?php echo e(route('auth.register')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="tittle-login">
                <h3>Forget Password</h3>
            </div>
            <div class="input-information">
                <div class="input-user input">
                    <label for="" style="font-size:20px;">Recovery email</label> <br>
                    <input id="recovery_email" type="email" name="email" spellcheck="false" require="require" value="admin@admin.vn"><br>
                </div>
            </div>
            <div class="btn-login">
                <button type="submit" id="btn-sendmail">Gửi mail</button>
            </div>
            <div class="login-api">
                <p style="text-align: center;">Sign in with</p>
                <ul>
                    <li><a href="#"><i style="color: rgb(39, 145, 244);" class="fa-brands fa-facebook fa-xl"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-github fa-xl"></i></a></li>
                    <li><a href=""><i style="color: rgb(249, 50, 5);" class="fa-brands fa-google fa-xl"></i></a></li>
                </ul>
            </div>
            <div class="information-support">
                <span><a href="<?php echo e(route('login')); ?>">Login</a></span>
                <span><a href="<?php echo e(route('auth.register')); ?>">Register</a></span>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\noob\resources\views/auth/forgetPassword.blade.php ENDPATH**/ ?>