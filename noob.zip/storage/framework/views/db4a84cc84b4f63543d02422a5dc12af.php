

<?php $__env->startSection('content'); ?>
<div id="main">
    <div class="alert-danger" style="display: none;">Đăng nhập thất bại!</div>
    <div class="form">
        <form action="<?php echo e(route('auth.login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="tittle-login">
                <h3>LOGIN</h3>
            </div>
            <div class="input-information">
                <div class="input-user input">
                    <label for="">Email</label> <br>
                    <input id="email" type="email" name="email" spellcheck="false" require="require" value="admin@admin.vn"><br>
                </div>
                <div class="input-pass input">
                    <label for="">Password</label><br>
                    <input type="password"  id="password" name="password"  require="require" value="123456"><br>
                </div>
            </div>
            <div class="btn-login">
                <button type="submit" id="btn-validate" >Login</button>
            </div>
            <div class="save-user" style="margin-bottom: 10px">
                <input class="remember-login" name="remember" type="checkbox">
                <label for="">Lưu đăng nhập</label>
            </div>
            <div class="login-api">
                <p style="text-align: center;">Sign in with</p>
                <ul>
                    <li><a href="#"><i style="color: rgb(39, 145, 244);" class="fa-brands fa-facebook fa-xl"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-github fa-xl"></i></a></li>
                    <li><a href=""><i style="color: rgb(249, 50, 5);" class="fa-brands fa-google fa-xl"></i></a></li>
                </ul>
            </div>
            <div class="information-support">
                <span><a href="<?php echo e(route('auth.forgetPassword')); ?>">Forget Password</a></span>
                <span><a href="<?php echo e(route('auth.register')); ?>">Register</a></span>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\noob\resources\views/auth/login.blade.php ENDPATH**/ ?>