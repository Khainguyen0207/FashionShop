

<?php $__env->startPush('head'); ?>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/admin/img/logo-2.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/products.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="container">
        <?php echo $__env->make('layouts.categories.menubar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('overview'); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\noob\resources\views/layouts/categories/products.blade.php ENDPATH**/ ?>