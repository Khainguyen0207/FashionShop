<div class="menu-bar">
    <ul class="list-menu">
        <div class="review">
            <p><?php echo e($name_category); ?></p>
            <a href="#logo"><img src="<?php echo e(asset('assets/admin/img/logo.png')); ?>" alt="logo"></a>
        </div>

        <div class="menu">
            <ul>
                <li>
                    <a href="<?php echo e(route('category.products.home', $id)); ?>">
                        <span><i class="fa-solid fa-shop"></i> Sản phẩm thời trang</span>
                        
                    </a>
                    <ul class="list-small">
                        
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('category.charts.home', $id)); ?>">
                        <span> <i class="fa-solid fa-chart-simple"></i> Thống kê đánh giá</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('category.vouchers.home', $id)); ?>">
                        <span><i class="fa-solid fa-ticket"></i> Chương trình khuyến mãi</span>
                    </a>
                </li>
                <li>
                    <a class="btn-del btn-action"  data-url="del" href="#">
                        <span><i class="fa-solid fa-trash"></i> Xóa danh mục</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="footer-menu">
            <a href="<?php echo e(route('categories.home')); ?>"><i class="fa-solid fa-arrow-left"></i> Quay lại</a>
        </div>
    </ul>
</div><?php /**PATH C:\laragon\www\noob\resources\views/layouts/categories/menubar.blade.php ENDPATH**/ ?>