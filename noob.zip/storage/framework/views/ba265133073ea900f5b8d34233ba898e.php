<?php $__env->startPush('footer'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/table.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopPush(); ?>

<div class="table-form">
    <table>
        <thead> 
            <tr class="head">
                <th></th>
                <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="table-info"><?php echo e($item); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th>Thông tin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $body; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $item = collect($item)->toArray()
                ?>
                <tr class="body">
                    <td><input type="checkbox"></td>
                        <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($item[$key_data])): ?>
                                <td class="table-info"><?php echo e($item[$key_data]); ?></td>
                            <?php else: ?>
                                <td class="table-info">Không xác định</td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <div class="btn">
                            <a class="btn-edit btn-action" title="Edit" data-url="<?php echo e($url); ?>/edit/<?php echo e($item['id']); ?>" href="#"><i class="fa-solid fa-pen-to-square"></i></a>
                            <a class="btn-del btn-action" title="Delete" data-url="<?php echo e($url); ?>/del/<?php echo e($item['id']); ?>" href="#">
                                <i class="fa-solid fa-trash-can" ></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="pages">
    <?php if($number != 1): ?>
        <a class="num-page" href=" <?php echo e($url); ?>?page=1"><i class="fa-solid fa-arrow-left"></i></a>
        <a class="num-page" href="<?php echo e($url); ?>?page=<?php echo e($number - 1); ?>"><?php echo e($number - 1); ?></a>
    <?php endif; ?>
    <a class="num-page" style="background-color: #00d6eb; border-radius: 5px; color: white;"  href="<?php echo e($url); ?>?page=<?php echo e($number); ?>"><?php echo e($number); ?></a>
    <?php if($number != $maxPage): ?>
        <a class="num-page" href="<?php echo e($url); ?>?page=<?php echo e($number + 1); ?>"><?php echo e($number + 1); ?></a>
        <a class="num-page"  onmouseover="window.status='your text';" href="<?php echo e($url); ?>?page=<?php echo e($maxPage); ?>"><i class="fa-solid fa-arrow-right"></i></a>
    <?php endif; ?>
</div>

<?php /**PATH C:\laragon\www\noob\resources\views/layouts/table.blade.php ENDPATH**/ ?>